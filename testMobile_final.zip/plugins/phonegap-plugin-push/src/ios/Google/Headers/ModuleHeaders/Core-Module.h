#if defined(__has_include)
# if __has_include(<Google/Core.h>)
#  include <Google/Core.h>
# endif
#endif
